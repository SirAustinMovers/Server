import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'phone-call',
    templateUrl: 'phone-call.component.html'
})

export class PhoneCallComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}