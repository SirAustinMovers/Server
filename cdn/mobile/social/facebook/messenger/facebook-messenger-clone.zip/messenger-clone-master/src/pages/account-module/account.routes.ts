export const AccountRoutes = {
    ACCOUNT: "account",
    PHONE_NUMBERS: "account/phone-numbers",
    NOTIFICATION_SETTINGS: "account/notification-settings"
}