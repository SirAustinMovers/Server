export const AppConfig = {
    tabsPlacement: "top"
}