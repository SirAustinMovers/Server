import {Component, OnInit} from "@angular/core";

@Component({
    selector: 'group-chat',
    templateUrl: 'group-chat.component.html'
})

export class GroupChatComponent implements OnInit {
    constructor() {
    }

    ngOnInit() {
    }
}