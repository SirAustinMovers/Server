import {Component} from "@angular/core";

@Component({
    selector: 'phone-numbers',
    templateUrl: './phone-numbers.component.html'
})
export class PhoneNumbersComponent {

}