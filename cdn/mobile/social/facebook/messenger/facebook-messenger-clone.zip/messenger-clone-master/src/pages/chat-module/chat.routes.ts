export const ChatRoutes = {
    LIST: "chat/list",
    SINGLE: "chat/single",
    GROUP: "chat/group",
}