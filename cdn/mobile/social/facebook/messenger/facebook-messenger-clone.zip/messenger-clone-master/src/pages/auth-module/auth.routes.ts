export const AuthRoutes = {
    LOGIN: "auth/login",
    LANDING: "auth/landing",
    SIGNUP: "auth/signup"
}