import {Component, OnInit} from "@angular/core";

@Component({
    selector: 'chatbox',
    templateUrl: 'chatbox.component.html'
})
export class ChatboxComponent implements OnInit {
    constructor() {
    }

    ngOnInit() {
    }
}