export class Message {
    public receiverId:string;
    public time:string;
    public content:string;
    public receiverName:string;
    public receiverAvatar:string;
    public senderName:string;
    public senderAvatar:string;
    public amSender:boolean;
    public otherOnline:boolean;
}