export const AppCommonsRoutes = {
    USER_PROFILE: "commons/user-profile",
    TUTORIAL: "commons/tutorial",
    ALL_PAGES: "commons/pages",
    COMING_SOON: "commons/coming-soon",
}