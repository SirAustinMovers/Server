export class Conversation {
    id:string;
    otherName:string;
    otherAvatar:string;
    otherReadStatus:string;
    otherOnlineStatus:string;
    lastMessage:string;
    lastMessageTime:string;
    myReadStatus:string;
    amLastSender:boolean;
}